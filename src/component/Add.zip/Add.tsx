import React, { useEffect, useState } from "react";
import { useForm, Controller } from "react-hook-form";
import {
  TextField,
  Button,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  FormHelperText,
  OutlinedInput,
} from "@mui/material";
import ReactQuill from "react-quill";
import "react-quill/dist/quill.snow.css";
import { useNavigate, useParams } from "react-router-dom";
import { enqueueSnackbar } from "notistack";

const Add = ({ rows, setRows }) => {
  const { register, handleSubmit, formState, control, setValue } = useForm();

  const { id } = useParams();
  const navigate = useNavigate();
  const [text, setText] = useState("");
  const [type, setType] = useState("Task");
  const [status, setStatus] = useState("active");

  useEffect(() => {
    if (id) {
      const data = rows.find((row) => row.id === Number(id));
      if (data) {
        setValue("name", data.name);
        setValue("description", data.description);
        setValue("type", data.type);
        // setValue("status", data.status);
        setValue("status", data.status || "");
        setText(data.description);
      }
    }
  }, [id, rows, setValue]);

  const onSubmit = (data) => {
    if (id) {
      update(id, data);
      return;
    }
    data.id = Date.now();
    setRows((prevRows) => [...prevRows, data]);
    enqueueSnackbar("Create successfully", {
      variant: "success",
      anchorOrigin: { vertical: "top", horizontal: "center" },
      autoHideDuration: 1000,
    });
    navigate("/");
  };

  const update = (id, item) => {
    const idx = rows.findIndex((i) => i.id === Number(id));
    item.id = Number(id);
    rows[idx] = item;
    setRows([...rows]);
    enqueueSnackbar("Update successfully", {
      variant: "success",
      anchorOrigin: { vertical: "top", horizontal: "center" },
      autoHideDuration: 1000,
    });
    navigate("/");
  };

  const handleChangeType = (event) => {
    setType(event.target.value);
    // setValue("type", event.target.value);
  };

  const handleChangeStatus = (event) => {
    setStatus(event.target.value);
    // setValue("status", event.target.value);
  };

  const typeValue = [
    { value: "Task", label: "Task" },
    { value: "SubTask", label: "SubTask" },
  ];

  const statusType = [
    { value: "active", label: "Active" },
    { value: "inactive", label: "Inactive" },
  ];

  return (
    <div>
      <h2 style={{ textAlign: "center" }}>{id ? "Update" : "Create"}</h2>
      <form
        onSubmit={handleSubmit(onSubmit)}
        style={{ margin: "auto", width: "60%" }}
      >
        <div>
          <TextField
            id="outlined-basic"
            label="Name"
            variant="outlined"
            fullWidth
            margin="normal"
            {...register("name", {
              required: "Name is required",
              minLength: 3,
            })}
            error={!!formState.errors.name}
            helperText={
              formState.errors.name ? formState.errors.name.message : ""
            }
          />
        </div>
        <div>
          <FormControl
            sx={{ mt: 1, width: 1100 }}
            error={!!formState.errors.type}
          >
            <InputLabel id="demo-multiple-name-label">Type</InputLabel>
            <Select
              value={type}
              labelId="demo-multiple-name-label"
              id="demo-multiple-name"
              {...register("type", { required: "Type is required" })}
              onChange={handleChangeType}
              input={<OutlinedInput label="Type" />}
            >
              {typeValue.map((option) => (
                <MenuItem key={option.value} value={option.value}>
                  {option.label}
                </MenuItem>
              ))}
            </Select>
            {formState.errors.type && (
              <FormHelperText>
                {formState?.errors?.type?.message}
              </FormHelperText>
            )}
          </FormControl>
        </div>
        <div>
          <FormControl
            sx={{ mt: 1, mb: 1, width: 1100 }}
            error={!!formState.errors.status}
          >
            <InputLabel id="demo-multiple-name-label">Status</InputLabel>
            <Select
              value={status}
              labelId="demo-multiple-name-label"
              id="demo-multiple-name"
              {...register("status", { required: "Status is required" })}
              onChange={handleChangeStatus}
              input={<OutlinedInput label="Status" />}
            >
              {statusType.map((opt) => (
                <MenuItem key={opt.value} value={opt.value}>
                  {opt.label}
                </MenuItem>
              ))}
            </Select>
            {formState.errors.status && (
              <FormHelperText>
                {formState?.errors?.status?.message}
              </FormHelperText>
            )}
          </FormControl>
        </div>
        <div>
          <div
            className={formState.errors.description ? "quill-editor-error" : ""}
          >
            <Controller
              control={control}
              {...register("description", {
                required: "Description is required",
                minLength: 3,
              })}
              render={({ field }) => (
                <ReactQuill
                  {...field}
                  theme="snow"
                  value={text}
                  onChange={(value) => {
                    setText(value);
                    field.onChange(value);
                  }}
                  className={
                    formState.errors.description ? "quill-editor-error" : ""
                  }
                />
              )}
            />
          </div>
          <p className="MuiFormHelperText-root Mui-error MuiFormHelperText-sizeMedium MuiFormHelperText-contained css-1wc848c-MuiFormHelperText-root">
            {formState?.errors?.description?.message}
          </p>
        </div>
        <div>
          <Button
            type="submit"
            variant="contained"
            style={{ marginTop: "20px" }}
          >
            {id ? "Update" : "Create"}
          </Button>
        </div>
      </form>
    </div>
  );
};

export default Add;
